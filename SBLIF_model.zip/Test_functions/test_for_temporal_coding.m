% test for temporal coding - vector strength between the input pulse train
% and the spike-train output of the model

%load the data from neurophys studies
load neurophysiological_data_from_literature.mat

%% Set parameters for the evaluations
nTest = 100;
PhaseDuration = 40;   %micro  sec
ipg = 30;  % 30
fs=1e6;
pRates = [50 100 200 400 800 1000 1250 1600 2500 5000];
stimL =.2*fs; %200 ms
t = 1:.2e6; % time vector for calculation of vector strength

nPulses = floor(.2.*pRates);

pulse = [ones(round(PhaseDuration),1);zeros(round(ipg),1);-1*ones(round(PhaseDuration),1)];

%%  First, determine 90% spiking efficiency for a single pulse
singlePulse = [zeros(PhaseDuration,1);pulse;zeros(PhaseDuration,1)];
lvls = (100:10:5000)*1e-6;
probs = zeros(length(lvls),1);
parfor levelInd=1:length(lvls)
    I = singlePulse*lvls(levelInd);
    probabilites = NaN*ones(nTest,1);
    for testInd=1:nTest
        [~,~,~,temp] = SBLIF_model(-I', fs);
        probabilites(testInd) = isfinite(temp.Prob_blif);
    end
    probs(levelInd) = mean(probabilites(isfinite(probabilites)));
end
bval = glmfit(lvls,probs,'binomial','probit');
xvals = (100:5000)*1e-6;
yhat = glmval(bval,xvals,'probit');
[~,ind] = min(abs(yhat-0.9));
level = xvals(ind);

% set stimulation levels to 90% single pulse probability current
levels = ones(size(pRates))*level;
levels(end-1:end) = levels(end-1:end) + [15, 30] *1e-6;
%% Tests with different pulse rates
InterPulseGap = round(1./pRates*fs);
vectorStr = zeros(length(pRates),nTest);
probabilities = zeros(length(pRates),1);
spikeRates = zeros(length(pRates),1);
onset_spikeRates = zeros(length(pRates),1);
average_spikeRates = zeros(length(pRates),1);
for rateInd=1:length(pRates)
    disp(['Now processing rate : ' num2str(pRates(rateInd))]);
    %Generate the pulse train
    sig = zeros(stimL,1);
    pulsePos = 2:InterPulseGap(rateInd):(stimL-length(pulse));
    pulseInd=1;
    while(pulseInd<=length(pulsePos))
       if((pulsePos(pulseInd)-1+length(pulse))<=length(sig))
        sig(pulsePos(pulseInd):(pulsePos(pulseInd)-1+length(pulse))) = pulse;
       end
       
        pulseInd=pulseInd+1;
    end
    I = [sig*levels(rateInd); zeros(1000,1)];
    tic;
    respsOur = zeros(length(I),nTest);
    timings = [];
    probs = [];
    parfor testInd =1:nTest
       [temp,spikeTimings,spikeProbs, outStruct]  = SBLIF_model(I', fs);
       timings = [timings,spikeTimings];
       probs = [probs,spikeProbs];
       respsOur(:,testInd) = temp(1:length(I))';
    end    
    probabilities(rateInd) = mean(probs);
    spikeRates(rateInd) = sum(respsOur(:))/(stimL/fs)/nTest;
    temp = respsOur(:);
    onset_spikeRates(rateInd) = sum(timings<=12e-3)/(12e-3)/nTest;
    average_spikeRates(rateInd) = sum(respsOur(:))/(stimL/fs)/nTest;
    disp(['Average firing rate: ' num2str(sum(respsOur(:))/(stimL/fs)/nTest) ' spikes/s']);
    disp('Vector strength computation');
    % tested vs rates
    start_rate = pRates(rateInd)/10;
    step = pRates(rateInd)/50;
    stop_rate = pRates(rateInd);
    % compute the vector strength using the external function
    vectorStr(rateInd,:) = synchVECS(respsOur',pRates(rateInd),1,pRates(rateInd),fs);

end
%% Compute descriptive statistics for the vector-strength values
vectorStr_means = zeros(length(pRates),1);
vectorStr_sds = zeros(length(pRates),1);

for rateInd=1:length(pRates)
    vectorStr_means(rateInd) = mean(vectorStr(rateInd,isfinite(vectorStr(rateInd,:))));
    vectorStr_sds(rateInd) = std(vectorStr(rateInd,isfinite(vectorStr(rateInd,:))));
end
%% Plot the results with the neurophysiological data
figure(10);
h(2) = semilogx(temporal_coding_data.HartmannKlinke.frqs-0.02* temporal_coding_data.HartmannKlinke.frqs,...
     temporal_coding_data.HartmannKlinke.averages,'k*');
hold on;
h(1)=semilogx(temporal_coding_data.DynesDelgutte.frq+0.02*temporal_coding_data.DynesDelgutte.frq,...
    temporal_coding_data.DynesDelgutte.averages,'ob');
for frqInd=1:length(temporal_coding_data.DynesDelgutte.frq)
    h(4)= line((temporal_coding_data.DynesDelgutte.frq(frqInd)+0.02*temporal_coding_data.DynesDelgutte.frq(frqInd))...
        *ones(1,2),temporal_coding_data.DynesDelgutte.cis(frqInd,:));
end
for frqInd=1:length(temporal_coding_data.HartmannKlinke.frqs)
    h(3)= line((temporal_coding_data.HartmannKlinke.frqs(frqInd)-0.02*temporal_coding_data.HartmannKlinke.frqs(frqInd))...
        *ones(1,2),temporal_coding_data.HartmannKlinke.cis(frqInd,:),'color','black');
end
h(5) = semilogx(temporal_coding_data.Miller.frqs-0.02*temporal_coding_data.Miller.frqs,...
    temporal_coding_data.Miller.avg,'ms');
for frqInd=1:length(temporal_coding_data.Miller.frqs)
    h(7)= line((temporal_coding_data.Miller.frqs(frqInd)-0.02*temporal_coding_data.Miller.frqs(frqInd))*ones(1,2),temporal_coding_data.Miller.avg(frqInd)+...
        [-temporal_coding_data.Miller.std(frqInd,:) temporal_coding_data.Miller.std(frqInd,:)],'color','magenta');
end
h(7) = semilogx(pRates,vectorStr_means,'-dr','markerfacecolor','red');
for rateInd=1:length(pRates)
    line(pRates(rateInd)*ones(1,2),vectorStr_means(rateInd)+[-vectorStr_sds(rateInd) vectorStr_sds(rateInd)],'color','red');
end
ylabel('Vector strength');
xlabel('Pulse rate');
legend([h(2) h(1) h(5) h(7)],'Hartmann and Klinke (1990)','Dynes and Delgutte (1992)',...
     'Miller et al. (2008)','model prediction','location','southwest');
xlim([45 5500]);ylim([0 1.01]);
set(gca,'xtick',[50 100 500 1000 5000]);
set(gca,'xticklabel',[50 100 500 1000 5000]);