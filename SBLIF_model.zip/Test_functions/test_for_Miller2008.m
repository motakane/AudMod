%Experiments from Miller et al 2008

%load neurophysiological data from literature
load neurophysiological_data_from_literature.mat -mat

%% Parameters for the tests
fs = 1e6;
pulseRates = [250, 1000, 5000];
InterPulseGap = 1./pulseRates*fs;
ipg=10e-6;
phaseL = 40e-6*fs;
stimL = 300e-3*fs;

nTests = 100;

pulse = [ones(round(phaseL),1);zeros(round(ipg*fs),1);-1*ones(round(phaseL),1)*1];

%% Create pulse sequences
sig = zeros(stimL,3);
t = (1:stimL)./fs;

for ind=1:length(pulseRates)
    pulsePos = 2:InterPulseGap(ind):(stimL-length(pulse));
    pulseInd=1;
    while(pulseInd<=length(pulsePos))
       if((pulsePos(pulseInd)-1+length(pulse))<=length(sig))
        sig(pulsePos(pulseInd):(pulsePos(pulseInd)-1+length(pulse)),ind) = pulse;
       end
       
        pulseInd=pulseInd+1;
    end
end

%% Test for IPIs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lvl = [1100 1200 1100]*1e-6;
steady_counts = zeros(length(pulseRates),nTest);
xBins = (0:0.05:30)*1e-3;
ydata=zeros(length(xBins),length(pulseRates));
ydata200=zeros(length(0:0.2:30),length(pulseRates));
for rateInd = 1:length(pulseRates)
    I = sig(1:50e3,rateInd)*lvl(rateInd);
    intervals = [];
    parfor testInd=1:nTest
        [~,spikeTimings]= SBLIF_model(I',fs );   

        steady_counts(rateInd,testInd) = length(spikeTimings);
        intervals = [intervals;diff(spikeTimings((spikeTimings>4e-3)))'];
    end
    [ydata(:,rateInd), xdata]= hist(intervals,xBins);
    [ydata200(:,rateInd), xdata]= hist(intervals,(0:0.2:30)*1e-3);

end
%% Plot results with neurophysiological data

spike_rate_adaptation_Miller2008.at250pps(isnan(spike_rate_adaptation_Miller2008.at250pps))=0;
spike_rate_adaptation_Miller2008.at1000pps(isnan(spike_rate_adaptation_Miller2008.at1000pps))=0;
spike_rate_adaptation_Miller2008.at5000pps(isnan(spike_rate_adaptation_Miller2008.at5000pps))=0;

%correlations between model and neuro data
model_250 = ydata(1:4:end,1)./max(ydata(1:4:end,1));
model_1000 = ydata(1:4:end,2)./max(ydata(1:4:end,2));
model_5000 = ydata(1:4:end,3)./max(ydata(1:4:end,3));

figure(9);
g(1)=subplot(1,3,1);
plot(xBins*1000,ydata(:,1)./max(ydata(:,1)),'-k',...
    xBins*1000,spike_rate_adaptation_Miller2008.at250pps,'r');
xlabel('ISI [ms]');
set(gca,'xlim',[1 22]);
ylabel('Normalized spike count');
legend('Model','Miller, 2008');
title('250 ppps');
g(2)=subplot(1,3,2);
plot(xBins*1000,ydata(:,2)./max(ydata(:,2)),'-k',xBins*1000,...
    spike_rate_adaptation_Miller2008.at1000pps,'r');
xlabel('ISI [ms]');
set(gca,'xlim',[1 16]);
legend('Model','Miller, 2008');
title('1000 ppps');
g(3)=subplot(1,3,3);plot(xBins*1000,ydata(:,3)./max(ydata(:,3)),'-k',...
    xBins*1000,spike_rate_adaptation_Miller2008.at5000pps,'r');
xlabel('ISI [ms]');
set(gca,'xlim',[1 16]);
legend('Model','Miller, 2008');
title('5000 ppps');