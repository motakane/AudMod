%Tests for Heffer et al. 2010 J Neurophys article

% once again load the neurophysiological data
load neurophysiological_data_from_literature.mat -mat

%% Set parameters for tests
fs = 1e6;
nTest=100;

pulseRates = [200 1000 2000 5000];
ipg = 8e-6*fs;
phaseL = 25e-6*fs;

stimL = 20e-3*fs;

% vector for a single pulse
pulse = [ones(round(phaseL),1);zeros(round(ipg),1);-1*ones(round(phaseL),1)*1];

%% Create pulse train sequences
% initiate a matrix for the different pulse trains
sig = zeros(stimL,length(pulseRates));
t = (1:stimL)./fs;

for ind=1:length(pulseRates)
    pulsePos= find(mod(t,1/pulseRates(ind))==0);
    pulseInd=1;
    while(pulseInd<=length(pulsePos))
       if((pulsePos(pulseInd)-1+length(pulse))<=length(sig))
        sig(pulsePos(pulseInd):(pulsePos(pulseInd)-1+length(pulse)),ind) = pulse;
       end
        pulseInd=pulseInd+1;
    end
end


%% find THR-value for a single pulse
single = [zeros(200e-6*fs,1);pulse;zeros(200e-6*fs,1)];
lvls = (500:5:3000)*1e-6;
probs = zeros(length(lvls),1);
parfor levelInd=1:length(lvls)
    I = single*lvls(levelInd);
    probabilities = NaN*ones(nTest,1);
    for testInd=1:nTest
        [~,~,~,temp] = SBLIF_model(I', fs);
        probabilities(testInd) = isfinite(temp.Prob_blif);
    end
    probs(levelInd) = mean(probabilities);
end
% estimate the threshold based on logistic function fitted to the
% probabilities
bval = glmfit(lvls,probs,'binomial','link','probit');
xval = lvls;
yhat = glmval(bval,xval,'probit');
thrL = xval(find(yhat>=0.5,1,'first'));

%% Find the stimulation levels corresponding to different "single-pulse spiking probabilities"
prob_levels = [(0.02:0.02:0.18)' (0.3:0.05:0.7)' (0.75:0.025:0.95)'];
final_probs = zeros(size(prob_levels));
stim_levels = zeros(size(prob_levels));
for ind=1:numel(prob_levels)
    stim_levels(ind) = xval(find(yhat>prob_levels(ind),1,'first'));
    final_probs(ind) = yhat(find(yhat>prob_levels(ind),1,'first'));
end

%% Compute the probabilities that a given pulse train evokes a spike during the first two ms
probabilities = zeros(length(pulseRates),size(stim_levels,1),size(stim_levels,2),nTest);
predicted_probabilities = probabilities;
for rateInd=1:length(pulseRates)
    disp(['Now processing pulse rate: ' num2str(pulseRates(rateInd))]);
    pulsePos= find(mod(t,1/pulseRates(rateInd))==0,1,'first');
    nPulses = length(strfind(sig((pulsePos:pulsePos+2e3)-1,rateInd)'>0,[0 1]));
    for levelInd=1:size(stim_levels,2)
        for probInd=1:size(stim_levels,1)
            predicted_probabilities(rateInd,probInd,levelInd,:) = min(1,nPulses*final_probs(probInd,levelInd));%min(1,nPulses*prob_levels(probInd,levelInd));
            disp(['At level no: ' num2str(levelInd) '/' num2str(size(stim_levels,2))]);
            I = sig(:,rateInd)*stim_levels(probInd,levelInd);
            probs = zeros(nTest,1);
            parfor testInd=1:nTest
                [~,spikeTimings] = SBLIF_model(I', fs);
                if(~isempty(spikeTimings))
                    probs(testInd) = spikeTimings(1)*fs<=(pulsePos+2e3);
                end
            end
            probabilities(rateInd,probInd,levelInd,:) = probs;
        end
    end
end
%% Compute the statistics for comparison with the neurophysiological data
averaged_probs = zeros(length(pulseRates),size(prob_levels,2),2);
var_probs = zeros(length(pulseRates),size(prob_levels,2),2);
median_probs = averaged_probs;quartile_probs=var_probs;

multp = [1 2 4 10];
for rateInd=1:length(pulseRates)
    for levelInd=1:size(prob_levels,2)
        tempProb = squeeze(probabilities(rateInd,:,levelInd,:));
        averaged_probs(rateInd,levelInd,1) = mean(mean(tempProb,2));
        var_probs(rateInd,levelInd,1) = std(mean(tempProb,2))./sqrt(length(prob_levels));
        averaged_probs(rateInd,levelInd,2) = mean(mean(tempProb,2)-squeeze(predicted_probabilities(rateInd,:,levelInd,1))');
        var_probs(rateInd,levelInd,2) = std(mean(tempProb,2)-squeeze(predicted_probabilities(rateInd,:,levelInd,1))')./sqrt(length(prob_levels));
        median_probs(rateInd,levelInd,2) = median(mean(tempProb,2)-squeeze(predicted_probabilities(rateInd,:,levelInd,1))');
        quartile_probs(rateInd,levelInd,:) = quantile(mean(tempProb,2)-squeeze(predicted_probabilities(rateInd,:,levelInd,1))',[0.25 0.75]);
    end
    
end

%% Plot the results into graph
figure(5);
titles ={'Low stimulation level','Medium stimulation level','High stimulation level'};
for levelInd=1:size(prob_levels,2)
    g(levelInd) = subplot(1,3,levelInd);
    h(1)=plot(data_Heffer2010(levelInd).change(1:4,1)-5,data_Heffer2010(levelInd).change(1:4,2),'--sr','markerfacecolor','red');
    hold on;
    plot(data_Heffer2010(levelInd).change(5:6,1)-5,data_Heffer2010(levelInd).change(5:6,2),'r','HandleVisibility','off');
    plot(data_Heffer2010(levelInd).change(7:8,1)-5,data_Heffer2010(levelInd).change(7:8,2),'r','HandleVisibility','off');
    plot(data_Heffer2010(levelInd).change(9:10,1)-5,data_Heffer2010(levelInd).change(9:10,2),'r','HandleVisibility','off');
    plot(data_Heffer2010(levelInd).change(11:12,1)-5,data_Heffer2010(levelInd).change(11:12,2),'r','HandleVisibility','off');
    h(2)=plot(pulseRates+100,squeeze(median_probs(:,levelInd,2)),'--dk','markerfacecolor','black');
    for rateInd=1:length(pulseRates)
        plot((pulseRates(rateInd)+100)*ones(1,2),squeeze(quartile_probs(rateInd,levelInd,:)),'-k');
    end
    title(titles(levelInd));
    xlabel('Pulse rate (pps)');
    if(levelInd==1)
        ylabel('Spike probability change');
    end
   
    line([0 10000],[0 0],'Color','k','LineStyle','-')
    legend('Heffer et al. (2010)','Model')
end
linkaxes(g,'xy');
set(gca,'xlim',[100 5500]);
set(gca,'ylim',[-0.45 0.8]);