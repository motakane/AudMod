%Experiments of Miller 2011 JARO article

% load neurophys data
load neurophysiological_data_from_literature.mat -mat

%% Set parameters for the evaluation
fs=1e6;
nTest = 100;

%boolean value to state if the script shall (for speed skip) computation
%of the number of spikes the probe and masker pulse trains evoke at
%different intensities
do_not_skip_determination_of_presentation_levels = 0;

probe_pulseRate = 100;
masker_pulseRate = [250 5000];
InterPulseGap = 1./masker_pulseRate*fs;

maskerL = 250e-3*fs;
probeL = 200e-3*fs;
ipg=30e-6*fs;
phaseL = 40e-6*fs;

% vector for single pulse
pulse = [ones(round(phaseL),1);zeros(round(ipg),1);-1*ones(round(phaseL),1)*1];

%% Create pulse train sequences
maskerSignals = zeros(maskerL,2);
for maskerInd=1:2
    pulsePos = 11:InterPulseGap(maskerInd):(maskerL-length(pulse));
    pulseInd=1;
    while(pulseInd<=length(pulsePos))
       if((pulsePos(pulseInd)-1+length(pulse))<=length(maskerSignals))
        maskerSignals(pulsePos(pulseInd):(pulsePos(pulseInd)-1+length(pulse)),maskerInd) = pulse;
       end
       
        pulseInd=pulseInd+1;
    end
end

probeSignal = zeros(probeL,1);
t = (1:probeL)./fs;
InterPulseGap = 1./probe_pulseRate*fs;
pulsePos = 11:InterPulseGap:(probeL-length(pulse));
pulseInd=1;
while(pulseInd<=length(pulsePos))
    if((pulsePos(pulseInd)-1+length(pulse))<=length(probeSignal))
        probeSignal(pulsePos(pulseInd):(pulsePos(pulseInd)-1+length(pulse))) = pulse;
    end
    pulseInd=pulseInd+1;
end

%% check the proper level for the probe stimulus
%according to article, 70% firing efficiency is targeted
if do_not_skip_determination_of_presentation_levels
    lvls = (300:20:1200)*1e-6;
    probs = zeros(length(lvls),1);
    disp('Now processign probe');
    for levelInd=1:length(lvls)
        disp(['At stim level no:' num2str(levelInd) '/' num2str(length(lvls))]);
        I = probeSignal*lvls(levelInd);
        firingCount = NaN*ones(nTest,1);
        parfor testInd=1:nTest
            [~,spikeTimings,spikeProbs] = SBLIF_model(I', fs);
            firingCount(testInd) = length(spikeTimings);
        end
        probs(levelInd) = mean(firingCount);
    end
    %firing efficiency
    efficiency = probs./(pulseInd-1);
end 
%% and the same for the maskers
if do_not_skip_determination_of_presentation_levels
    lvls2 = (600:10:800)*1e-6;
    probs2 = zeros(length(lvls2),2);
    for maskerInd=1:2
        disp(['Now processign masker at pulse rate of' num2str(masker_pulseRate(maskerInd))]);
        for levelInd=1:length(lvls2)
            disp(['At stim level no:' num2str(levelInd) '/' num2str(length(lvls2))]);
            I = maskerSignals(:,maskerInd)*lvls2(levelInd);
            firingCount = NaN*ones(nTest,1);
            for testInd=1:nTest
                [~,spikeTimings,spikeProbs] = SBLIF_model(I', fs);
                firingCount(testInd) = length(spikeTimings);
            end
            probs2(levelInd,maskerInd) = mean(firingCount);
        end
    end
end 
%% Test for the effects of accommodation
probeLevel = 780e-6;

% selected levels for the masker
maskerLevel = [950 775 690 620 580 550 450]'*1e-6;
endP = [find(maskerSignals(:,1)~=0,1,'last') find(maskerSignals(:,2)~=0,1,'last')];
OutStr2 = {};
for maskerInd=1:2
    masker = [maskerSignals(1:endP(maskerInd),maskerInd);zeros(1/masker_pulseRate(maskerInd)*fs,1)];
    disp(['Now processign using the ' num2str(masker_pulseRate(maskerInd)) ' pulses/s masker']);
    for levelInd=1:length(maskerLevel)
        disp(['At masker level no: ' num2str(levelInd) '/' num2str(length(maskerLevel))]);
        startP = find(probeSignal~=0,1,'first');
        I = [masker*maskerLevel(levelInd);probeSignal(startP:end)*probeLevel];
        OutStr2(maskerInd,levelInd).signal = I;
        timings = cell(1, nTest);
        thr_crossings = cell(1, nTest);
        parfor testInd=1:nTest
            [~,spikeTimings,spikeProbs,temp] = SBLIF_model(I', fs);
            timings(testInd) = mat2cell(spikeTimings,1);
            thr_crossings(testInd) = mat2cell(temp.thrCrossings, 1);
        end
        OutStr2(maskerInd, levelInd).timings = timings;
        OutStr2(maskerInd,levelInd).thrCrossings = thr_crossings;
        OutStr2(maskerInd,levelInd).maskerL = length(masker)/fs;
    end
end
%% Compute spike-timings and spiking efficiency for probe presented in isolation
I = probeSignal*probeLevel;
timings = cell(1,nTest);
spike_count = 0;
parfor testInd=1:nTest
    [~,spikeTimings,spikeProbs,temp] = SBLIF_model(I', fs);
    timings(testInd) = mat2cell(spikeTimings,1);
    spike_count = spike_count + length(spikeTimings);
end
refFiringEff = spike_count / nTest / 200e-3;
%% histogram of firing patterns at different levels
figure(6);
k=1;
countVals = zeros(length(masker_pulseRate),length(maskerLevel));
probeRecovRatio = zeros(length(masker_pulseRate),length(maskerLevel));
limits = 101*ones(length(masker_pulseRate)*length(maskerLevel),1);
masker_firing_rates = zeros(length(masker_pulseRate),length(maskerLevel));
for levelInd=[1, 2, 5, 7]
    rateInd=2;
    maskerTimings = [];
    probeTimings = [];
    probeInIsolation = [];
    for testInd=1:nTest
        temp1 = cell2mat(OutStr2(rateInd,levelInd).thrCrossings(testInd));
        temp2 = cell2mat(OutStr2(rateInd,levelInd).timings(testInd));
        temp3 = cell2mat(timings(testInd));
        maskerTimings = [maskerTimings;temp2(temp2<=maskerL / fs)'];
        probeTimings = [probeTimings;temp2(temp2>maskerL / fs)'];
        probeInIsolation = [probeInIsolation; temp3'];
    end
    [y3,x3] = hist(probeInIsolation,(0.001:0.001:0.2));
    if(~isempty(maskerTimings))
        [y1,x1] = hist(maskerTimings,(0.001:0.001:0.26));
    else
        y1 = zeros(size(x1));
    end
    [y2,x2] = hist(probeTimings,x3'+.26);
    subplot(4,1,k);
    bar(x1, y1);hold on;bar(x3'+.26, y3, 'k');bar(x2',y2', 'r');hold off;
    set(gca,'xlim',[-.01 .45]);
    countVals(k) = sum(y1);
    probeRecovRatio(k) = sum(y2)./sum(y3);
    k=k+1;
end
xlabel('Time [s]')
%% compute the masker levels in dB (re masker THR)
levels_in_dB = zeros(length(maskerLevel), 2);
for rateInd=1:2
   for levelInd=1:length(maskerLevel)
       masker_firing = 0;
       for testInd=1:nTest
            temp1 = cell2mat(OutStr2(rateInd,levelInd).thrCrossings(testInd));
            temp2 = cell2mat(OutStr2(rateInd,levelInd).timings(testInd));
            temp3 = cell2mat(timings(testInd));
            masker_firing = masker_firing + length(temp2(temp2<=maskerL / fs));
       end
       masker_firing_rates(rateInd, levelInd) = masker_firing / nTest * 1 / 250e-3;
   end
   thr_level_ind = find(masker_firing_rates(rateInd,:) > 0, 1, 'last');
   levels_in_dB(:, rateInd) = 20 * log10(maskerLevel./ maskerLevel(thr_level_ind));
end
%% plot figure about probe recovery rate as function of masker rate
k=1;
probeRates = zeros(2, length(maskerLevel),nTest);
for levelInd=1:length(maskerLevel)
    for rateInd=1:2
        maskerTimings = [];
        probeTimings = [];
        for testInd=1:nTest
            temp1 = cell2mat(OutStr2(rateInd,levelInd).thrCrossings(testInd));
            temp2 = cell2mat(OutStr2(rateInd,levelInd).timings(testInd));
            probeTimings = temp2(temp1>maskerL / fs)';
            probeRates(rateInd,levelInd,testInd) = length(probeTimings)/200e-3;
        end
    end
end
figure(7);

probeRecoveryRate = mean(probeRates,3)./refFiringEff;
varProbeRecov = sqrt(var((probeRates./refFiringEff),[],3)./500);
g(1)=subplot(1,2,1);
plot(accommodation_Miller2011.Masker250.Raw.MaskerLevel, ...
    accommodation_Miller2011.Masker250.Raw.Recovery, ...
    'color', [0.5 0.5 0.5], 'marker', 'o', 'linestyle', 'none');
hold on;
plot(accommodation_Miller2011.Masker250.Medians.MaskerLevel, ...
    accommodation_Miller2011.Masker250.Medians.Recovery, '-rd', ...
    'markerFaceColor', 'r');
plot(levels_in_dB(:,1),probeRecoveryRate(1,:), '-ks', ...
    'markerFaceColor', 'k');
hold off;
ylabel('Probe recovery rate');
xlabel('Masker level [dB re THR]');
title('250 pulse/s masker');

g(2)=subplot(1,2,2);

plot(accommodation_Miller2011.Masker5000.Raw.MaskerLevel, ...
    accommodation_Miller2011.Masker5000.Raw.Recovery, ...
    'color', [0.5 0.5 0.5], 'marker', 'o', 'linestyle', 'none');
hold on;
plot(accommodation_Miller2011.Masker5000.Medians.MaskerLevel, ...
    accommodation_Miller2011.Masker5000.Medians.Recovery, '-rd', ...
    'markerFaceColor', 'r');
plot(levels_in_dB(:,2),probeRecoveryRate(2,:), '-ks', ...
    'markerFaceColor', 'k');
hold off;
xlabel('Masker level [dB re THR]');
title('5000 pulse/s masker');
linkaxes(g,'xy');
set(gca,'ylim',[-0.1 1.5]);
set(gca,'xlim',[-4 5]);

