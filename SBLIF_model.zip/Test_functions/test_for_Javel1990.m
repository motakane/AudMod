%Tests for Javel 1990 thesis

load neurophysiological_data_from_literature.mat -mat
%% Set parameters for the evaluation
nTest = 100;
fs = 1e6;
pulseRates = [100,200,400,800];
ipg = 0;
phaseL = 50e-6*fs;
stimL = 100e-3*fs;

shift = -7.2; % shift in dB for the spiking efficiency data

% vector for the single biphasic pulse
pulse = [ones(round(phaseL),1);zeros(round(ipg),1);-1*ones(round(phaseL),1)*1];

%% Generate the pulse train sequences
sig = zeros(stimL,length(pulseRates));
t = (1:stimL)./fs;

for ind=1:length(pulseRates)
    pulsePos = 11:round(1/pulseRates(ind)*fs):(stimL-length(pulse));
    pulseInd=1;
    while(pulseInd<=length(pulsePos))
       if((pulsePos(pulseInd)-1+length(pulse))<=length(sig))
        sig(pulsePos(pulseInd):(pulsePos(pulseInd)-1+length(pulse)),ind) = pulse;
       end
        pulseInd=pulseInd+1;
    end
end
%% testing at different stimulus levels
lvls = (400:10:2000)*1e-6;

counts = zeros(length(pulseRates),length(lvls));
for rateInd=1:length(pulseRates)
    disp(['Now processing pulse rate: ' num2str(pulseRates(rateInd))]);
    signal = sig(:,rateInd);
    parfor levelInd=1:length(lvls)
        disp(['At level no: ' num2str(levelInd) '/' num2str(length(lvls))]);
        I = signal*lvls(levelInd);
        for testInd=1:nTest
            [outSig,spikeTimings,spikeProbs, outStruct] = SBLIF_model(I', fs);
            counts(rateInd,levelInd) = counts(rateInd,levelInd)+length(spikeTimings);
        end
    end
end 
%% compute firing efficiency
efficiency = zeros(length(lvls),length(pulseRates));
figure(8);
for rateInd=1:length(pulseRates)
    pulsePos = 11:round(1/pulseRates(rateInd)*fs):(stimL-length(pulse));
    efficiency(:,rateInd) = min(1, counts(rateInd,:)./nTest/length(pulsePos));
end
%% Plot the results
figure(8);
xvals = lvls;
for rateInd=1:size(efficiency,2)
    switch rateInd
        case 1
            plot(20*log10(xvals./1e-6)+shift,efficiency(:, rateInd),'b-');
        case 2
            plot(20*log10(xvals./1e-6)+shift,efficiency(:, rateInd),'r-');
        case 3
            plot(20*log10(xvals./1e-6)+shift,efficiency(:, rateInd),'g-');
        case 4
            plot(20*log10(xvals./1e-6)+shift,efficiency(:, rateInd),'k-');
    end
    hold on
end
h(1)=plot(data_Javel1990.hundred(:,1),data_Javel1990.hundred(:,2),'ob','markerfacecolor','blue');hold on;
h(2) = plot(data_Javel1990.twoH(:,1),data_Javel1990.twoH(:,2),'sr','markerfacecolor','red');
h(3) = plot(data_Javel1990.fourH(:,1),data_Javel1990.fourH(:,2),'<g','markerfacecolor','green');
h(4) = plot(data_Javel1990.eightH(:,1),data_Javel1990.eightH(:,2),'>k','markerfacecolor','black');
xlabel('Stimulus level (dB re 1 \muA)');
ylabel('Firing efficiency (spikes/pulses)');
set(gca,'xlim',[49 62]);
xlim([48 58])
legend('model, 100 pps','model, 200 pps','model, 400 pps','model, 800 pps',...
       'Javel, 100 pps','Javel, 200 pps','Javel, 400 pps','Javel, 800 pps')
       