%% Testing for refratoriness

% load all neurophysiological data
load neurophysiological_data_from_literature.mat -mat
%Data of Dynes, Cartee and Miller
% inter-pulse intervals in the digitized data are given in mu_s
xdata=10^-6*[refractoriness.ipiDynes;refractoriness.ipiMiller;refractoriness.ipiCartee];
ydata=([refractoriness.thrDynes;refractoriness.thrMiller;refractoriness.thrCartee]);

%% Set Parameters
nTest = 100;
fs = 1e6;
t_stim = 40e-6; %Monophasic pulse t_stim microsec
stimulus = [zeros(1,fs*10^-4), ones(1,fs*t_stim), zeros(1,fs*10^-4)];
levels = (150:5:1000)*1e-6;
stimuli = levels' * stimulus;
nSpikes = zeros(length(levels),1);



parfor i = 1:length(levels)
    for j = 1:nTest
        [~,t] = SBLIF_model(stimuli(i,:), fs);%cathodic
        nSpikes(i)=nSpikes(i) + ~isempty(t);
    end
end

nSpikes=nSpikes/nTest;

%Indice of the 50% threshold
i_I0_50 = 1;

while nSpikes(i_I0_50)<0.5
    i_I0_50 = i_I0_50 + 1;
end

% 50% threshold
I_thr_50 = levels(i_I0_50);%Between 3e-4 

%Indice of the 99% threshold
i_I0_99 = i_I0_50;

while nSpikes(i_I0_99)<.91
    i_I0_99 = i_I0_99 + 1;
end

% 99% threshold
I_thr_99 = levels(i_I0_99); %3.1e-4



%% Refractoriness condition
%Interpulse intervals (IPI)
Dt = 100/fs.*[5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 22 24 26 28 30 32 35 40 45 50 60 75 90 120];

n_Dt = length(Dt);

%Level
lvl = (-0.1:0.1:20); %in dB
n_lvl = length(lvl);

%First pulse (t_stim microsec and monophasic)
stim1 = [zeros(1,fs*10^-4), I_thr_99*ones(1,fs*t_stim)]; %should fire 90% of the time

%Probability
prob = zeros(n_Dt,n_lvl);

% 50% threshold
thr = Inf(n_Dt,1);

parfor i = 1:n_Dt
    disp(['Now processing time ' num2str(Dt(i))]);
    
    %Interpulse interval (between the two onsets)
    inter = zeros(1,round(fs*(Dt(i)-t_stim)));
    
    %Was the threshold already crossed?
    isThrFound = 0;  
    
    for j = 1:n_lvl
        %Second pulse
        stim2 = [I_thr_50*10^(lvl(j)/20)*ones(1,round(fs*t_stim)),zeros(1,fs*10^-4)];
        %Total stimulus
        stimulus = [stim1,inter,stim2];
        %Number of valid answers (first spike really elicited)
        n_valid=0;
        
        %We test this stimulus nTests time.
        while n_valid < nTest
            [~,t] = SBLIF_model(stimulus, fs);
            % If only the first spike was elicited
            if length(t)==1 
                n_valid = n_valid+1;
            %If two spikes were elicited
            elseif length(t)==2
                n_valid = n_valid+1;
                prob(i,j)=prob(i,j)+1;  
            end
        end
        
        %Compute the probability
        prob(i,j)= prob(i,j)/n_valid;
        
        %If the threshold is being crossed, save it
        if prob(i,j)>0.5 && ~isThrFound
            thr(i) = lvl(j);
            isThrFound = 1;
            break
        end
        
    end
    
end

%% Data analysis
figure(3);
plot(10^-3*refractoriness.ipiMiller,refractoriness.thrMiller,'dr',...
    10^-3*refractoriness.ipiCartee,refractoriness.thrCartee,'ob',...
    10^-3*refractoriness.ipiDynes,refractoriness.thrDynes,'*m',...
    Dt*10^3,thr,'-k');
legend('Miller, 2001','Cartee, 2000','Dynes, 1996','model prediction','location','northeast');
xlabel('Inter-pulse-interval [ms]');
ylabel('Threshold relative to single pulse THR [dB]')
