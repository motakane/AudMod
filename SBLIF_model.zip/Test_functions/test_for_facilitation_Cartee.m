%tests for Cartee 2000 facilitation

% load neurophysiological data from literature
load neurophysiological_data_from_literature.mat -mat

%% Set parameters for testing
fs = 1e6;
phaseDur = 50e-6*fs; 
ipi = 100:25:500; % range of inter-pulse intervals

lvls = (400:5:800)*1e-6; % range of stimulus amplitudes (Ampere)
nTest=100; % number of tests
probs = zeros(length(lvls),1); %initiatial values for probabilities 
thrVal = zeros(length(ipi),2); % and threshold values

%% Test sequence for different inter-pulse intervals
for ipiInd=1:length(ipi)
    disp(['Now processing IPI : ' num2str(ipiInd) '/' num2str(length(ipi))]);
    % create the pulse(s) for the two conditions
    pulse = [ones(phaseDur,1);-1*ones(ipi(ipiInd)-phaseDur,1)./((ipi(ipiInd)-phaseDur)/phaseDur)];    %pulse= [ones(phaseDur,1);-50e-6/(5*(1-exp(-(ipi(ipiInd)-50)/5e6))).*exp(-(1:(ipi(ipiInd)-50))/5e6)'];
    single = [zeros(200e-6*fs,1);pulse;zeros(200e-6*fs,1)];
    double = [zeros(200e-6*fs,1);pulse;pulse;zeros(200e-6*fs,1)];
    
    % iterate over different stimulation levels
    for levelInd=1:length(lvls)
        I = single*lvls(levelInd);
        if (ipi(ipiInd)>500)
            I2 = [zeros(200e-6*fs,1);pulse*10^(-2/20)*596.7e-6;pulse*lvls(levelInd);zeros(200e-6*fs,1)];
        else
            I2 = double*lvls(levelInd);
        end
        probabilities = NaN*ones(nTest,1);
        probabilities2 = probabilities;

        % and over different test iterations
        parfor testInd=1:nTest
            [outSig,spikeTimings,spikeProbs, temp] = SBLIF_model(I',fs);
            probabilities(testInd) = ~isnan(temp.tSpk);
            [outSig,spikeTimings,spikeProbs, temp] = SBLIF_model(I2', fs);
            probabilities2(testInd) = ~isnan(temp.tSpk);     
        end
        % compute the average probability that the modeled neuron spiked
        probs(levelInd,1) = mean(probabilities(isfinite(probabilities)));
        probs(levelInd,2) = mean(probabilities2(isfinite(probabilities2)));        
    end
    % fit logistic regression model to the probabilites and estimate the
    % threshold values
    bval1 = glmfit(lvls,probs(:,1),'binomial','probit');
    bval2 = glmfit(lvls,probs(:,2),'binomial','probit');
    xval = linspace(150e-6,2*max(lvls),3000);
    yhat = glmval(bval1,xval,'probit');
    [~,ind] = min(abs(yhat-0.5));
    thrVal(ipiInd,1) = xval(ind);
    yhat = glmval(bval2,xval,'probit');
    [~,ind] = min(abs(yhat-0.5));
    thrVal(ipiInd,2) = xval(ind);
end

%% Plot the results
figure(4);
h(1) = plot([100 200 300],facilitation_Cartee2000.means,'sr','markerfacecolor','red');
hold on;
line([100 100],facilitation_Cartee2000.means(1)+[-facilitation_Cartee2000.cis(1) facilitation_Cartee2000.cis(1)],'color','red');
line([200 200],facilitation_Cartee2000.means(2)+[-facilitation_Cartee2000.cis(2) facilitation_Cartee2000.cis(2)],'color','red');
line([300 300],facilitation_Cartee2000.means(3)+[-facilitation_Cartee2000.cis(3) facilitation_Cartee2000.cis(3)],'color','red');
h(2) = plot(facilitation_Cartee2000.vals_for_ipiEq,facilitation_Cartee2000.ipiEq,'--b');
h(3) = plot(ipi,thrVal(:,2)./thrVal(:,1),'-m');
legend([h(1) h(2) h(3)],{'Data by Cartee, 2000','Fit by Cartee, 2000','Model prediction'},'location','SouthEast');
xlabel('Inter-pulse interval [\mus]');
ylabel('Threshold relative to single-pulse THR');
set(gca,'xlim',[95 400]);
set(gca,'ylim',[0.65 1.05]);