function [outSig,spikeTimings,spikeProbs, outStruct] = SBLIF_model(insig, fs)
%S-BLIF model (version 1.0.0) for electrically stimulated auditory nerve fiber
%
%   Usage: [outSig,tSpk,Prob_blif] = SBLIF_model(insig, fs)
%
%   Input parameters:
%        insig     : signal used to electrically stimulate the AN fiber.
%                    The input is to given as a vector of current (in Ampere)
%                    sampled at the given sample rate.
%        fs        : sample rate of the input. 
%
%   Output parameters:
%        outsig        : signal consisting mainly of zeros but having
%                        value(s) of one at the time(s) of spiking. Here,
%                        a sample rate of 1 MHz is used.
%        spikeTimings  : the time(s) [s] when the AN fiber spikes if it 
%                        does so. Otherwise an empty vector is returned
%        spikeProbs    : the firing probability of the BLIF AN fiber at 
%                        each time of spiking. Otherwise an empty vector is
%                        returned
%   Matlab implementation of the sequential biphasic leaky integrate-and-
%   fire model presented in Takanen and Seeber (submitted). The S-BLIF
%   model extends the BLIF model (Horne, Summer and Seeber, 2016) for 
%   pulse-train stimulation. 
%
%
%   References:
%     M. Takanen and B.U. Seeber. A phenomenological model reproducing
%     temporal response characteristics of electrically stimulated auditory
%     nerve fiber. Submitted for publication. (2021)
%
%     C. Horne, C.J. Sumner, and B.U. Seeber. A phenomenological model of
%     the electrically stimulated auditory nerve fiber: temporal and
%     biphasic response properties. Front. Comp. Neurosci. (2016)
%
%   Version 1.0.0
%
%   Marko Takanen, 2021
%*********************************************************************

%% check the input parameters
if fs ~= 1e6
   insig = resample(insig, 1e6, fs); 
end
sz = size(insig);
if sz(1) > sz(2)
   insig = insig'; 
end

%% initiate parameters according to the manuscript and the original model by Colin

parameters.fs = 1e6;

% time constant of the fiber
parameters.leaky_integrator_filter.tau = 2.4841e-04; 

%coeffs for the leaky integrator (1st order IIR) filter 
parameters.leaky_integrator_filter.b = [(1-exp(-1/(parameters.leaky_integrator_filter.tau*parameters.fs)))/2 ...
    (1-exp(-1/(parameters.leaky_integrator_filter.tau*parameters.fs)))/2];
parameters.leaky_integrator_filter.a = [1 -exp(-1/(parameters.leaky_integrator_filter.tau*parameters.fs))];

%mean and standard deviation of the threshold of the fiber
parameters.mu = 1.0454e-04*[1 1];
parameters.sigma = 4.5954e-06*[1 1];

%minimum duration of the action potential initialization process
parameters.varphi = 3.5e-05;

%parameter that defines the length of the time window within which the
%firing probability is integrated to potentially generate a spike
parameters.omega = 1e-05;

%coefficients required in the computation of the jitter and latency of the
%firing as specified in Table 1 of the manuscript
parameters.jitterCoeffs = [109 3.24 136]*1e-6;
parameters.latencyCoeffs = [106 5.14 368 472]*1e-6;

%long-term adaptation
parameters.adaptation.tau = 0.125;
parameters.adaptation.mu = 0.01; 
parameters.adaptation.std = 0.01;
parameters.adaptation.max_adap = 1.38; % upper limit for adaptation effect

%coefficients for modeling the refractoriness
parameters.refractoriness.p =0.7567;
parameters.refractoriness.q = 8.774e-3;
parameters.refractoriness.mu_trrp = 1.5e-3;
parameters.refractoriness.sigma_trrp = 0.4e-3;
parameters.refractoriness.mu_tarp = 0.3e-3;
parameters.refractoriness.sigma_tarp = 0.05e-3;

%coefficients for the active component of facilitation
parameters.facilitation.coeffs = [1.30404494036148e-09 -2.41510556161260e-06 0.00168277635816475 0.510071403244025];

parameters.spikeCount = 0;

%% initiate output parameters
outSig = zeros(size(insig));
spikeTimings = [];
firedNeuron = [];
spikeProbs = [];
tSpk = NaN;
tZero = NaN;
Prob_blif = NaN;
tOne =NaN;


outStruct.tZero = NaN;
outStruct.tOne = NaN;
outStruct.tSpk = NaN;
outStruct.Prob_blif = NaN;
outStruct.jitter = NaN;
outStruct.latency = NaN;
outStruct.thrCrossings = [];
outStruct.latencies = [];

%% start the processing 

peakVoltage = zeros(length(insig),1);

%check for onsets of pulses
temporary_Volt = cumsum(insig');

onsets = strfind(abs(temporary_Volt)'>1e-6,[0 1]);
% Now, the thr is randomized separately for each time instant
thr_value = randn(length(insig),2).*(ones(length(insig),1)*parameters.sigma)+(ones(length(insig),1)*parameters.mu);

%in the new model the signal is processed in a loop, where the
%THR-crossings are detected from a given time instant onwards. That is,
%starting from t=0 and thereafter updating t=tSpk+1
startTime = 1;

%membrane voltage
Voltage = filter(parameters.leaky_integrator_filter.b, parameters.leaky_integrator_filter.a, insig');

multiplyer_vals = polyval(parameters.facilitation.coeffs,1:1000)';
multiplyer_vals = multiplyer_vals(multiplyer_vals<=1);


parameters.mu_thr = ones(length(insig),1)*parameters.mu;
parameters.adaptation_increment = ones(length(insig),1);

while(startTime<length(insig))
    offsets.cathodic = strfind((Voltage>0)',[1 0]);
    offsets.anodic = strfind((-1*Voltage>0)',[1 0]);
    timeVector = startTime:length(insig);
    %look for time instances when the neuron was almost excited, and
    %emulate the active component of facilitation
    onset_temp = onsets(onsets>=startTime);
    offset_temp = offsets.cathodic(offsets.cathodic>startTime);
    for onsetInd=1:min(length(onset_temp),length(offset_temp))
        nValues = min(offset_temp(onsetInd)+length(multiplyer_vals),length(insig))-offset_temp(onsetInd);
        thr_value(offset_temp(onsetInd)+(1:nValues),1) = ...
            randn(nValues,1)*parameters.sigma(1)+parameters.mu_thr(offset_temp(onsetInd)+(1:nValues),1).*multiplyer_vals(1:nValues);
    end
    offset_temp = offsets.anodic(offsets.anodic>startTime);
    for onsetInd=1:min(length(onset_temp),length(offset_temp))
        nValues = min(offset_temp(onsetInd)+length(multiplyer_vals),length(insig))-offset_temp(onsetInd);
        thr_value(offset_temp(onsetInd)+(1:nValues),2) = ...
            randn(nValues,1)*parameters.sigma(2)+parameters.mu_thr(offset_temp(onsetInd)+(1:nValues),2).*multiplyer_vals(1:nValues);
    end
    %find out when the cathodic or anodic polarities would excite the
    %neuron
    t0_cathodic = timeVector(Voltage(timeVector)>thr_value(timeVector,1));
    t0_anodic = timeVector(-1*Voltage(timeVector)>thr_value(timeVector,2));
    tZeroCrossings = [];
    polarityExcited =[];
    if(~isempty(t0_cathodic))
        tZeroCrossings = t0_cathodic;
        polarityExcited = ones(size(t0_cathodic));
    end
    if(~isempty(t0_anodic))
        tZeroCrossings = [tZeroCrossings t0_anodic];
        polarityExcited = [polarityExcited 2*ones(size(t0_anodic))];
    end
    if(isempty(tZeroCrossings))
        startTime = length(insig);
        continue;      
    end
    [tZeroCrossings,ind] = sort(tZeroCrossings);
    polarityExcited = polarityExcited(ind);
    nucleiSpiked =0;
    nextStartingP = length(insig);
    
    while(~isempty(tZeroCrossings) && ~nucleiSpiked)%(nucleiIndex<=2 && ~nucleiSpiked)
        tZero = tZeroCrossings(1);
        polarityType = polarityExcited(1);
        
        %find out when the fiber is repolarized, i.e. when the membrane voltage
        %becomes larger than 0 after anodic pulse or smaller than 0 after
        %cathodic pulse. This determines the time when the pulse is cancelled
        tempTime = timeVector(timeVector>=tZero);
        temp = cumsum(insig(tempTime));
        switch polarityType
            case 1
                peakVoltage(timeVector) = cummax(Voltage(timeVector));
                QZero = tempTime(temp<0)+1;
            case 2
                peakVoltage(timeVector) = cummax(-1*Voltage(timeVector));
                QZero = tempTime(temp>0)+1;
        end
        
        %if the signal is monophasic (i.e. the membrane voltage does not cross
        %zero after THR-crossing)
        if(isempty(QZero))
            QZero = Inf;           
        end
        QZero = QZero(1);
        %check whether the time difference between QZero and tZero is smaller than
        %the minimun delay of the action potential initialization process, if it is
        %cancel the spike
        if (tZero+parameters.varphi*parameters.fs>=QZero)
            %if so, look for the next THR-crossing starting from the present
            %value
            temp = polarityExcited((tZeroCrossings<=QZero).*(polarityExcited==polarityType)==0);
            tZeroCrossings((tZeroCrossings<=QZero).*(polarityExcited==polarityType)==1) = [];
            polarityExcited = temp;
            continue;
        end
        
        %if not, estimate the time tOne, when the initialization process has been
        %completed
        
        %the initial estimate is obatained by solving
        %hatTOne(t) = tZero+Y*jit(P(t)) = t, when t e [tZero+phi,QZero]
        
        %computation is based on P_blif that depends on the voltage and whether
        %an anodic or cathodic pulse excited the fiber in the first place
        tempProb = normcdf(peakVoltage((tZero+round(parameters.varphi*parameters.fs)):min(length(insig),QZero)),...
            parameters.mu(polarityType),parameters.sigma(polarityType));
        temp = (exprnd(1)*computeJitter_based_on_probability(tempProb,parameters))*ones(1,2)...
            +[-(0:(length(tempProb)-1))'./parameters.fs  zeros(size(tempProb))];
        hatTOne= temp(temp(:,1)<0,2);
        if(isempty(hatTOne))
            hatTOne =0;
        else
            hatTOne= hatTOne(1);
        end
        tOne = round(hatTOne*parameters.fs+parameters.varphi*parameters.fs+tZero);
        
        %check whether the initialization process lasts too long, so that it's
        %value exceeds QZero, i.e. the time when the spike is cancelled
        if (tOne>=QZero(1))
            %if so, look for the next THR-crossing starting from the present
            %value
            temp = polarityExcited((tZeroCrossings<=QZero(1)).*(polarityExcited==polarityType)==0);
            tZeroCrossings((tZeroCrossings<=QZero(1)).*(polarityExcited==polarityType)==1) = [];
            polarityExcited = temp;
            continue;
        end
        
        %if not, estimate the time of spiking
        
        %this is done within a time window from tZero-C.omega to tZero+C.omega
        %however, there are special limitations that the current cannot be negative
        %within that region, otherwise there cannot be any spiking
        temptimeVect = max(1,tZero-round(parameters.omega*parameters.fs)):...
            min(tZero+round(parameters.omega*parameters.fs),length(insig));
        
        %again we need to solve the time QZero for each of those time instances
        QZeroS = Inf*ones(size(temptimeVect));
        for ind =1:length(temptimeVect)
            tempTime = timeVector(timeVector>=temptimeVect(ind));
            tempVolt = cumsum(insig(tempTime));
            switch polarityType
                case 1
                    tempTime = tempTime(tempVolt<0)+1;
                case 2
                    tempTime = tempTime(tempVolt>0)+1;
            end
            if(~isempty(tempTime))
                QZeroS(ind) = tempTime(1);
            end
        end
        %remove time instances that cannot evoke a spike
        temp = temptimeVect+parameters.varphi*parameters.fs-QZeroS;
        temptimeVect = temptimeVect(temp<0);
        QZeroS = QZeroS(temp<0);
        
        if(isempty(temptimeVect))
            temp = polarityExcited((tZeroCrossings<=QZero).*(polarityExcited==polarityType)==0);
            tZeroCrossings((tZeroCrossings<=QZero).*(polarityExcited==polarityType)==1) = [];
            polarityExcited = temp;
            continue;
        else
            %the processing continues only if there are time instanses at 
            %which spike could be evoked
    
            %compute  probability that t0 is within the interval [ts(i), ts(i)+dt).
            P = normcdf(peakVoltage(temptimeVect)',parameters.mu(polarityType),parameters.sigma(polarityType));
            tmpV = peakVoltage(min(length(insig)*ones(size(QZeroS)),QZeroS));
            % and the derivative of that function (see Eq.(12) in Colin et al)
            P = [P(1) diff(P)];
            
            %compute the probability that the spike is not cancelled at different
            %QOs
            tempJitter = computeJitter_based_on_voltage(tmpV',parameters);
            P_exp = 1-exp(-((QZeroS-temptimeVect)./parameters.fs-parameters.varphi)./...
                tempJitter);
            
            probability = P.*P_exp;
            %integrate over the time window
            Prob_blif = sum(probability);
            %estimate the time of spiking
            tSpk = tZero/parameters.fs+randn*computeJitter_based_on_probability(Prob_blif,parameters)+...
                computeLatency_based_on_probability(Prob_blif,parameters);
            lat = tSpk-tZero/parameters.fs;
            outStruct.thrCrossings = [outStruct.thrCrossings tZero./parameters.fs];
            outStruct.latencies = [outStruct.latencies; lat];
            %add a spike to the spike train
            outSig(round(tSpk*parameters.fs))=1;
            
            nucleiSpiked =1;
            
            spikeProbs = [spikeProbs Prob_blif];
            spikeTimings = [spikeTimings tSpk];
            firedNeuron = [firedNeuron polarityType];
            parameters.spikeCount = parameters.spikeCount+1;
            
            nextStartingP = round(tSpk*parameters.fs)+1;
            
            %emulate the refactory period by increasing the THR-value
            [thr_value, parameters] = increase_thr_to_emulate_refactory_period(thr_value,parameters,round(tSpk*parameters.fs),lat,nextStartingP(1));            
            
            %emulate long-term adaptation by increasing the THR-value upon every spiking
            [thr_value, parameters] = long_term_adaptation(thr_value,parameters,round(tSpk*parameters.fs));
            parameters.tLastAdapt = tSpk;
            %update the loop to continue from this time of spiking onwards
            Voltage(nextStartingP:end) = filter(parameters.leaky_integrator_filter.b, ...
                parameters.leaky_integrator_filter.a, insig(nextStartingP:end)');
        end
        
    end
    startTime = nextStartingP;
end
outStruct.tZero = tZero/parameters.fs;
outStruct.tOne = tOne/parameters.fs;
outStruct.tSpk = tSpk;
outStruct.Prob_blif = Prob_blif;
outStruct.jitter = computeJitter_based_on_probability(Prob_blif,parameters);
outStruct.latency = computeLatency_based_on_probability(Prob_blif,parameters);
outStruct.voltage = Voltage;
outStruct.thrVal = thr_value;
outStruct.firedNeuron = firedNeuron;
end
%%
%this function emulates the refactory period by increasing the firing
%threshold momentarily following the approach by Hamacher (2004)
function [thrs, parameters]= increase_thr_to_emulate_refactory_period(thrs,parameters,tSpk,lat,intTime)
    tRRP = parameters.refractoriness.mu_trrp+randn(1)*parameters.refractoriness.sigma_trrp;
    tARP = parameters.refractoriness.mu_tarp  - lat + ...
        max(0, tSpk - intTime)/parameters.fs;
    t= (((min(intTime,tSpk)+1):length(thrs))-min(intTime,tSpk))'./parameters.fs;
    
    %the refactory period is emulated by multiplying the (mean) thr-value
    %with a time-dependent coefficient defined in Eq. (6.25) at page 79 in
    %Hamacher (2004)
    
    thr_mult_coeff = ((1-exp(-(t-tARP)./(parameters.refractoriness.q*tRRP))).*(1-parameters.refractoriness.p*...
       exp(-(t-tARP)./tRRP))).^-1;
    thr_mult_coeff(t<= tARP) = Inf;

   parameters.mu_thr(min(intTime,tSpk)+1:end,:) = parameters.mu_thr(min(intTime,tSpk)+1:end,:).*thr_mult_coeff;%thr_mult_coeff*parameters.mu;
    % randomize new set of thr-values where the THR-is momentarily
    % increased 
   thrs(min(intTime,tSpk)+1:end,:) = randn(length(thr_mult_coeff),2).*(ones(length(thr_mult_coeff),1)*parameters.sigma)...
       +parameters.mu_thr(min(intTime,tSpk)+1:end,:);%(parameters.mu.*thr_mult_coeff);
end

%%
%A few additional functions to estimate the jitter and latency as
%described in the Table 1 of the manuscript by Horne et al.

function jitter = computeJitter_based_on_voltage(peakVoltage,param)
    jitter = param.jitterCoeffs(3)./(1+exp(param.jitterCoeffs(2)^-1*(peakVoltage-...
        param.jitterCoeffs(1))));
end

function jitter = computeJitter_based_on_probability(probability,param)
    probit = norminv(probability,param.mu(1),param.sigma(1));
    jitter = param.jitterCoeffs(3)./(1+exp(param.jitterCoeffs(2)^-1*(probit-...
        param.jitterCoeffs(1))));
end

function latency = computeLatency_based_on_probability(probability,param)
    probit = norminv(probability,param.mu(1),param.sigma(1));
    latency = param.latencyCoeffs(3)./(1+exp(param.latencyCoeffs(2)^-1*(probit-...
        param.latencyCoeffs(1))))+param.latencyCoeffs(4);
end

function [thrs, parameters] = long_term_adaptation(thrs,parameters,tSpk)
    t= (((tSpk+1):length(thrs))-tSpk)';
    
    max_incr = 1+(parameters.adaptation.mu+randn*parameters.adaptation.std); % maximum of exponential decay
    min_incr = 1; % minimum of exponential decay

    thr_increment = min_incr + (max_incr-min_incr)*exp(-t./(parameters.adaptation.tau*parameters.fs)); % create threshold increment function
    
    % calculate ratio between maximum of thr_increment and specified
    % maximum adaptation effect
    fact = max(parameters.adaptation_increment((tSpk+1):end,:).*thr_increment)/parameters.adaptation.max_adap;
     
    % if thr_increment exceeds allowed maximum, adapt function to exactly
    % reach the specified maximum adaptation effect
    if fact > 1
        max_incr = max(thr_increment)/fact;
        thr_increment = min_incr + (max_incr-min_incr)*exp(-t./(parameters.adaptation.tau*parameters.fs));        
    end
    
    % vector in which the multiplied thr_increments are stored
    parameters.adaptation_increment((tSpk+1):end,:) = parameters.adaptation_increment((tSpk+1):end,:).*thr_increment;
    
    % increase mean value of fiber threshold by increment
    parameters.mu_thr((tSpk+1):end,:) = parameters.mu_thr((tSpk+1):end,:).*thr_increment;
    % increase threshold vector by increment
    thrs(tSpk+1:end,:) = thrs(tSpk+1:end,:).*thr_increment;
end
