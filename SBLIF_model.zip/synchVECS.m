function [VS,P] = synchVECS (X,minHz,Hz_rez,maxHz,fs)
%% synchVECS
%%	- determines the degree of synchrony between two signals
%%  Input: 
%%		X = neurons or trails by time (2d matrix of spiking activity)
%%		minHz = minimum frequency of compared signal (i.e. oscillation)
%%		Hz_rez = resolution at which to change frequencies
%%		maxHz = maximum frequency of compared signal (i.e. oscillation)
%%	Output:
%%		VS = vector strength as a function of n and Hza
%%		P = probability of synchrony
HzInd =1;
for Hz = minHz:Hz_rez:maxHz									% 1) each frequency
	T = fs/Hz;%1000/Hz;											% 2) determine the period
    for n = 1:size(X,1)										% 3) for each neuron
		spikes = [];										% 4) initiate or clear spike times
		spikes = find(X(n,:)==1);  							% 5) find the time of each spike
		N(n,1) = sum(X(n,:));								% 6) compute the total number of spikes
		theta = [];											% 7) initialize theta
		for i = 1:size(spikes,2)							% 8) for each spike time
			theta(i,1) = 2 * pi * mod(spikes(1,i),T)/T;		% 9) determine spike time relative to phase [as degree, I think :-)]
		end
		x = sum(cos(theta));
		y = sum(sin(theta)); 
		VS(n,HzInd) = sqrt(x^2 + y^2) / N(n,1);				% 10) vector strength indexed by n and Hz
		P(n,HzInd) = 2 * VS(n,HzInd)^2 * N(n,1);					% 12) probability of synchrony by n and Hz
    end
    HzInd = HzInd+1;
end