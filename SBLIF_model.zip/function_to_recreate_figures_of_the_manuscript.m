% main script for generating all the figures in the manuscript 
%
% uses subfunctions to simulate the different experiments / temporal
% phenomena
%
% Digitized data from the original studies are located in the subfolder
% original_data (along with the necessary functions to load them into matlab
%
clear;close all;clc

%% Figure 3B (refractoriness)
run("Test_functions\test_for_refractoriness.m")
save refractoriness_results.mat -mat
clear;
%% Figure 4b (Cartee's facilitation experiment)
run("Test_functions\test_for_facilitation_Cartee.m")
save Cartee_results.mat -mat
clear;
%% Figure 5c (Accommodation and facilitation from Heffer's experiment)
run("Test_functions\test_for_Heffer2010.m")
save Heffer_results.mat -mat
clear
%% Figures 6 and 7 (accommodation with pulse trains (Miller et al 2011))
run("Test_functions\testsForMiller2011Paper.m")
save results_Miller2011.mat -mat
%% Figure 8 (Spike-rate adaptation) Javel's experiment
run("Test_functions\test_for_Javel1990.m")
save Javel_results_constant_ARP.mat -mat
%% Figure 9 (Spike-rate adaptation) Miller 2008
run("Test_functions\test_for_Miller2008.m")
save adaptation_results.mat -mat
clear
%% Figure 10 (temporal_coding)
run("Test_functions\test_for_temporal_coding.m")
save vector_strength_results.mat -mat
clear